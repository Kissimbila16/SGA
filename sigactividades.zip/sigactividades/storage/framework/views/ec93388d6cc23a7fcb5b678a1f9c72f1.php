<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP\Documents\DOMINGOS WORKSPACE\laravel11-react-spa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>