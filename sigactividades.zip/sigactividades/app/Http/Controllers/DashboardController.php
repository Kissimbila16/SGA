<?php

namespace App\Http\Controllers;

use App\Http\Resources\TaskResource;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller {
    public function index() {
        $user = auth()->user();
        $totalPendingTasks = Task::query()
        ->where( 'status', 'pending' )
        ->count();
        $myPendingTasks = Task::query()
        ->where( 'status', 'pending' )
        ->where( 'assigned_user_id', $user->id )
        ->count();

        $totalProgressTasks = Task::query()
        ->where( 'status', 'in_progress' )
        ->count();
        $myProgressTasks = Task::query()
        ->where( 'status', 'in_progress' )
        ->where( 'assigned_user_id', $user->id )
        ->count();

        $taskTable = Task::all();
        $taskTable->where( '*' );

        $totalCompletedTasks = Task::query()
        ->where( 'status', 'completed' )
        ->count();
        $myCompletedTasks = Task::query()
        ->where( 'status', 'completed' )
        ->where( 'assigned_user_id', $user->id )
        ->count();

        $activeTasks = Task::query()
        ->where( 'assigned_user_id', $user->id )
        ->limit( 10 )
        ->get();
        //  dd( $activeTasks );
        $activeTasks = TaskResource::collection( $activeTasks );

        $currentDate = Carbon::now()->format( 'd-m-y' );
        // Format date for comparison
        $Tasks = Task::query()
        ->where( 'due_date', '>', $currentDate )
        ->where( 'assigned_user_id', $user->id )
        ->limit( 10 )
        ->get();

        $primeiraTabela = Task::orderBy( 'due_date', 'desc' )->first();
        $created_atTabela1 = $primeiraTabela->created_at;

        // Consulta para obter o valor de created_at da segunda tabela
        $segundaTabela = Task::orderBy( 'created_at', 'desc' )->first();
        $created_atTabela2 = $segundaTabela->created_at;

        // Comparação das colunas created_at das duas tabelas
        if ( $created_atTabela1 < $created_atTabela2 ) {
           // due e maior ou nao ha nada
            $Tasks = false;
        } else {
         //due e menor data de criaçao de maior
            $Tasks = true;
        }
        return inertia(
            'Dashboard',
            compact(
                'totalPendingTasks',
                'myPendingTasks',
                'totalProgressTasks',
                'myProgressTasks',
                'totalCompletedTasks',
                'myCompletedTasks',
                'activeTasks',
                'Tasks',
                'taskTable'
            ),
        );
    }
}
