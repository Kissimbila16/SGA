<?php

namespace App\Http\Controllers;

use App\Http\Resources\ProjectResource;
use App\Http\Resources\TaskResource;
use App\Http\Resources\UserResource;
use App\Models\Project;
use App\Models\Task;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;



class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $query = Task::query();

        $user = User::all();
        $user_id = auth()->user()->id;
       $user = User::where("type_user", $user_id);
        $user_tipo = $user->first();

        $query2 = DB::table('users') // Replace with your actual table name
        ->select('*') // Select all columns (you can specify specific columns if needed)
        ->where('id',  $user_id) // Filter by 'name' equal to 'domingos'
        ->get(); // Execute the query and get the results

        if($query2[0]->type_user == "admin"){
               $user = "admin";
        }else{
            $user = "normal";
        }
        $sortField = request("sort_field", 'created_at');
        $sortDirection = request("sort_direction", "desc");

        if (request("name")) {
            $query->where("name", "like", "%" . request("name") . "%")
            ->orWhere("assunto", "like", "%" . request("name") . "%")
            ->orWhere("num_interno", "like", "%" . request("name") . "%")
            ->orWhere("conteudo_despacho", "like", "%" . request("name") . "%")
            ->orWhere("due_date", "like", "%" . request("name") . "%");
        }
        if (request("status")) {
            $query->where("status", request("status"));
        }

        $tasks = $query->orderBy($sortField, $sortDirection)
            ->paginate(10)
            ->onEachSide(1);

        return inertia("Task/Index", [
            "userTable" => $user,
            "tasks" => TaskResource::collection($tasks),
            'queryParams' => request()->query() ?: null,
            'success' => session('success'),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $projects = Project::query()->orderBy('name', 'asc')->get();
        $users = User::query()->orderBy('name', 'asc')->get();

        return inertia("Task/Create", [
            'projects' => ProjectResource::collection($projects),
            'users' => UserResource::collection($users),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTaskRequest $request)
    {
        $data = $request->all();
        $currentDate = Carbon::now()->format('d-m-y');
        /** @var $image \Illuminate\Http\UploadedFile */
        $image = $data['image'];
        $data['created_by'] = Auth::id()?:null;
        $data['created_at'] = $currentDate?:null;
        $data['updated_by'] = Auth::id()?:null;
        $data = $request->except(['image']);
        if ($image) {
            $data['image_path'] = $image->store('task/' . Str::random(), 'public');
        }else{
            $data['image_path'] = null;
        }
      //  dd($data); 

       // Task::create($data);
       $query2 = DB::table('tasks') // Replace with your actual table name
       ->insert($data);
        return to_route('task.index')
            ->with('success', 'orientação criada com sucesso');
    }

    /**
     * Display the specified resource.
     */
    public function show(Task $task)
    {

        $user = User::all();
        $user_id = auth()->user()->id;
        $user = User::where("type_user", $user_id);
        $user_tipo = $user->first();

        if($user_tipo == "admin"){
               $user = "admin";
        }else{
            $user = "normal";
        }
        return inertia('Task/Show', [
            $user,
            'task' => new TaskResource($task),
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Task $task)
    {
        $projects = Project::query()->orderBy('name', 'asc')->get();
        $users = User::query()->orderBy('name', 'asc')->get();

        return inertia("Task/Edit", [
            'task' => new TaskResource($task),
            'projects' => ProjectResource::collection($projects),
            'users' => UserResource::collection($users),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTaskRequest $request, Task $task)
    {
        $data = $request->validated();
        $image = $data['image'] ?? null;
        $data['updated_by'] = Auth::id();
        if ($image) {
            if ($task->image_path) {
                Storage::disk('public')->deleteDirectory(dirname($task->image_path));
            }
            $data['image_path'] = $image->store('task/' . Str::random(), 'public');
        }
        $task->update($data);

        return to_route('task.index')
            ->with('success', "Task \"$task->name\" foi actualizado com sucesso");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Task $task)
    {
        $name = $task->name;
        $task->delete();
        if ($task->image_path) {
            Storage::disk('public')->deleteDirectory(dirname($task->image_path));
        }
        return to_route('task.index')
            ->with('success', "Task \"$name\" foi deletado com sucesso");
    }

    public function myTasks()
    {
        $user = auth()->user();
        $query = Task::query()->where('assigned_user_id', $user->id);

        $sortField = request("sort_field", 'created_at');
        $sortDirection = request("sort_direction", "desc");

        if (request("name")) {
            $query->where("name", "like", "%" . request("name") . "%")
            ->orWhere("assunto", "like", "%" . request("name") . "%")
            ->orWhere("num_interno", "like", "%" . request("name") . "%")
            ->orWhere("conteudo_despacho", "like", "%" . request("name") . "%")
            ->orWhere("due_date", "like", "%" . request("name") . "%")
            ;
        }
        
        if (request("status")) {
            $query->where("status", request("status"));
        }



        $tasks = $query->orderBy($sortField, $sortDirection)
            ->paginate(10)
            ->onEachSide(1);

        return inertia("Task/Index", [
            "tasks" => TaskResource::collection($tasks),
            'queryParams' => request()->query() ?: null,
            'success' => session('success'),
        ]);
    }
}
