<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserCrudResource;
use App\Models\User;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use Illuminate\Support\Facades\DB;

class UserController extends Controller {
    /**
    * Display a listing of the resource.
    */

    public function index() {
        $user = User::all();

        $user_id = auth()->user()->id;
        //  $user = User::where( 'type_user', 'admin' )->where( 'id', $user_id );
        $user_tipo = $user->first();

        $query2 = DB::table( 'users' ) // Replace with your actual table name
        ->select( '*' ) // Select all columns ( you can specify specific columns if needed )
        ->where( 'id',  $user_id ) // Filter by 'name' equal to 'domingos'
        ->get();
        // Execute the query and get the results

        // if ( $query2[ 0 ]->type_user == 'admin' ) {
        if ( $query2[ 0 ]->type_user == 'admin' ) {
            $user = 'admin';
        } else {
            $user = 'normal';
        }
        $query = User::query();

        $sortField = request( 'sort_field', 'created_at' );
        $sortDirection = request( 'sort_direction', 'desc' );

        if ( request( 'name' ) ) {
            $query->where( 'name', 'like', '%' . request( 'name' ) . '%' );
        }
        if ( request( 'email' ) ) {
            $query->where( 'email', 'like', '%' . request( 'email' ) . '%' );
        }

        $users = $query->orderBy( $sortField, $sortDirection )
        ->paginate( 10 )
        ->onEachSide( 1 );

        return inertia( 'User/Index', [

            'users' => UserCrudResource::collection( $users ),
            'queryParams' => request()->query() ?: null,
            'success' => session( 'success' ),
            'user_type' => $user?:null,
        ] );

    }

    /**
    * Show the form for creating a new resource.
    */

    public function create() {
        return inertia( 'User/Create' );
    }

    /**
    * Store a newly created resource in storage.
    */

    public function store( StoreUserRequest $request ) {
        $data = $request->validated();
        $data[ 'email_verified_at' ] = time();
        $data[ 'password' ] = bcrypt( $data[ 'password' ] );
        User::create( $data );

        return to_route( 'user.index' )
        ->with( 'success', 'Usuario foi criado com sucesso' );
    }

    /**
    * Display the specified resource.
    */

    public function show( User $user ) {
        //
    }

    /**
    * Show the form for editing the specified resource.
    */

    public function edit( User $user ) {
        return inertia( 'User/Edit', [
            'user' => new UserCrudResource( $user ),
        ] );
    }

    /**
    * Update the specified resource in storage.
    */

    public function update( UpdateUserRequest $request, User $user ) {
        $data = $request->validated();
        $password = $data[ 'password' ] ?? null;
        if ( $password ) {
            $data[ 'password' ] = bcrypt( $password );
        } else {
            unset( $data[ 'password' ] );
        }
        $user->update( $data );

        return to_route( 'user.index' )
        ->with( 'success', 'Usuario \'$user->name\' foi Actualizado com sucesso' );
    }

    /**
    * Remove the specified resource from storage.
    */

    public function destroy( User $user ) {
        $name = $user->name;
        $user->delete();
        return to_route( 'user.index' )
        ->with( 'success', 'Usuario \'$name\' foi deletado com sucesso' );
    }
}
