import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import SelectInput from "@/Components/SelectInput";
import TextAreaInput from "@/Components/TextAreaInput";
import TextInput from "@/Components/TextInput";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, Link, useForm } from "@inertiajs/react";

export default function Create({ auth }) {
  const { data, setData, post, errors, reset } = useForm({
    image: "",
    name: "",
    status: "",
    description: "",
    due_date: "",
  });

  const onSubmit = (e) => {
    e.preventDefault();
console.log(data)
    post(route("project.store"));
  };

  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <div className="flex justify-between items-center">
          <h2 className="font-semibold text-xl btn-color leading-tight">
            Criar Actividade
          </h2>
        </div>
      }
    >
      <Head title="Projects" /> 

      <div className="py-12">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="bg-white  overflow-hidden shadow-sm sm:rounded-lg">
            <form
              onSubmit={onSubmit}
              className="p-4 sm:p-8 text-gray-900  shadow sm:rounded-lg"
            >
              <div>
                <InputLabel
                style={{color:'#0d99ff'}}
                  htmlFor="project_image_path"
                  value="Actividade Imagem"
                />
                <TextInput
                  style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px',color:'black'}}
                  id="project_image_path"
                  type="file"
                  name="image"
                  className="mt-1 block w-full"
                  onChange={(e) => setData("image", e.target.files[0])}
                />
                <InputError message={errors.image} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel
                style={{color:'#0d99ff'}} htmlFor="project_name" value="Actividade Nome" />

                <TextInput
                  style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px',color:'black'}}
                  id="project_name"
                  type="text"
                  name="name"
                  value={data.name}
                  className="mt-1 block w-full"
                  isFocused={true}
                  onChange={(e) => setData("name", e.target.value)}
                />

                <InputError message={errors.name} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel
                style={{color:'#0d99ff'}}
                  htmlFor="project_description"
                  value=" Descrição do  Actividade"
                />

                <TextAreaInput
                  style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px',color:'black'}}
                  id="project_description"
                  name="description"
                  value={data.description}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("description", e.target.value)}
                />

                <InputError message={errors.description} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel
                style={{color:'#0d99ff'}}
                  htmlFor="project_due_date"
                  value="Data final da Actividade"
                />

                <TextInput
                  style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px',color:'black'}}
                  id="project_due_date"
                  type="date"
                  name="due_date"
                  value={data.due_date}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("due_date", e.target.value)}
                />

                <InputError message={errors.due_date} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel
                style={{color:'#0d99ff'}} htmlFor="project_status" value="Actividade estado" />

                <SelectInput
                  style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px',color:'black'}}
                  name="status"
                  id="project_status"
                  className="mt-1 block w-full"
                  onChange={(e) => setData("status", e.target.value)}
                >
                    <option value="" disabled>Selecione o Estado</option>
                  <option value="pending">Pendente</option>
                  <option value="in_progress">em Progresso</option>
                  <option value="completed">Cumprida</option>
                </SelectInput>

                <InputError message={errors.project_status} className="mt-2" />
              </div>
              <div className="mt-4 text-right">
                <Link
                  href={route("project.index")}
                  className="bg-gray-100 py-1 px-3 text-gray-800  shadow transition-all hover:bg-gray-200 mr-2"
                >
                  Cancelar
                </Link>
                <button className="bg-emerald-500 py-1 px-3 text-white  shadow transition-all hover:bg-emerald-600" style={{background:'#0d99ff'}} type="submit">
                  Submeter
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
