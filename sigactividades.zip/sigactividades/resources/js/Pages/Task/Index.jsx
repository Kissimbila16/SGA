import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";

import { Head, Link } from "@inertiajs/react";

import TasksTable from "./TasksTable";

export default function Index({ userTable, auth, success, tasks, queryParams = null }) {
  console.log(tasks)
  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-xl btn-color dark:text-gray-200 leading-tight">
          Orientações
          </h2>
          <Link
            href={route("task.create")}
            className="bg-emerald-500 py-1 px-3 text-white  shadow transition-all btn-bg"
          >
            Adicionar Novo
          </Link>
        </div>
      }
    >
     
      <Head title="Tasks" />

      <div className="py-12">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 text-gray-900 dark:text-gray-900">
              <TasksTable
                type_user = {userTable}
                tasks={tasks}
                queryParams={queryParams}
                success={success}
              />
            </div>
          </div>
        </div>
      </div>

      <h4>
      </h4>
    </AuthenticatedLayout>
  );
}
