import Pagination from "@/Components/Pagination";
import SelectInput from "@/Components/SelectInput";
import TextInput from "@/Components/TextInput";
import TableHeading from "@/Components/TableHeading";
import { TASK_STATUS_CLASS_MAP, TASK_STATUS_TEXT_MAP } from "@/constants.jsx";
import { Link, router } from "@inertiajs/react";
import { type } from "jquery";

export default function TasksTable({
  type_user,
  tasks,
  success,
  queryParams = null,
  hideProjectColumn = false,
}) {
  queryParams = queryParams || {};
  const searchFieldChanged = (name, value) => {
    if (value) {
      queryParams[name] = value;
    } else {
      delete queryParams[name];
    }

    router.get(route("task.index"), queryParams);
  };

  const onKeyPress = (name, e) => {
    if (e.key !== "Enter") return;

    searchFieldChanged(name, e.target.value);
  };

  const sortChanged = (name) => {
    if (name === queryParams.sort_field) {
      if (queryParams.sort_direction === "asc") {
        queryParams.sort_direction = "desc";
      } else {
        queryParams.sort_direction = "asc";
      }
    } else {
      queryParams.sort_field = name;
      queryParams.sort_direction = "asc";
    }
    router.get(route("task.index"), queryParams);
  };

  const deleteTask = (task) => {
    if (!window.confirm("Tens a certeza que queres deletar esta Orientação?")) {
      return;
    }
    router.delete(route("task.destroy", task.id));
  };

  return (
    <>
      {success && (
        <div className="bg-emerald-500 py-2 px-4 text-white rounded mb-4">
          {success}
        </div>
      )}
      <div className="overflow-auto">
        <div className="flex w-[99%] mb-3">
          <TextInput
            className="w-full bg-white h-[45px]"
            defaultValue={queryParams.name}
            placeholder="Nome da Orientação"
            style={{ background: 'white', borderWidth: '2px', borderColor: '#0d99ff', color: 'black' }}
            onBlur={(e) => searchFieldChanged("name", e.target.value)}
            onKeyPress={(e) => onKeyPress("name", e)}
          />

          <SelectInput
            className="w-full ml-3"
            defaultValue={queryParams.status}
            style={{ background: 'white', borderRadius: '0px', borderColor: '#0d99ff', borderWidth: '2px', color: 'black' }}
            onChange={(e) => searchFieldChanged("status", e.target.value)}
          >
            <option value="" disabled>Selecione o Estado</option>
            <option value="pending">Pendente</option>
            <option value="in_progresso">em Progresso</option>
            <option value="completed">Cumprida</option>
          </SelectInput>

        </div>
        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs btn-color uppercase bg-gray-100   dark:text-gray-200 border-b-2 border-gray-500">
            <tr className="text-nowrap">
              <TableHeading
                name="id"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                Nº
              </TableHeading>
              <th className="px-3 py-3">Imagem</th>
              {!hideProjectColumn && (
                <th className="px-3 py-3">Nome da Orientação</th>
              )}

              <TableHeading
                name="name"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                Assunto
              </TableHeading>


              <TableHeading
                name="name"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                conteudo de despacho
              </TableHeading>
              <TableHeading
                name="name"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                Nome
              </TableHeading>
              <TableHeading
                name="name"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                nº de Ordem
              </TableHeading>

              <TableHeading
                name="created_at"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >
                Data de Criação
              </TableHeading>

              <TableHeading
                name="due_date"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >

                prazo            
                  </TableHeading>
              <TableHeading
                name="status"
                sort_field={queryParams.sort_field}
                sort_direction={queryParams.sort_direction}
                sortChanged={sortChanged}
              >

                Grau de Comprimento
              </TableHeading>
              <th className="px-3 py-3">Criado por</th>
              {type_user == "admin" && <th className="px-3 py-3 text-right">Acção</th>}
            </tr>
          </thead>

          <tbody>
            {tasks.data.map((task) => (
              <tr
                className="text-gray-900 dark:border-gray-700"
                key={task.id}
              >
                <td className="px-3 py-2">{task.id}</td>
                <td className="px-3 py-2">
                  <img src={task.image_path} style={{ width: 60 }} />
                </td>
                {!hideProjectColumn && (
                  <td className="px-3 py-2">{task.project.name}</td>
                )}
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.assunto}</Link>
                </th>
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.conteudo_despacho}</Link>
                </th>
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.name}</Link>
                </th>
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.num_interno}</Link>
                </th>
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.created_at}</Link>
                </th>
                <th className="px-3 py-2 hover:underline">
                  <Link href={route("task.show", task.id)}>{task.due_date}</Link>
                </th>
                <td className="px-3 py-2">
                  <span
                    className={
                      "px-2 py-1 rounded text-nowrap text-white " +
                      TASK_STATUS_CLASS_MAP[task.status]
                    }
                  >
                    {TASK_STATUS_TEXT_MAP[task.status]}
                  </span>
                </td>
                <td className="px-3 py-2">{task.createdBy.name}</td>
                {type_user == "admin" && <td className="px-3 py-2 text-nowrap">
                  <Link
                    href={route("task.edit", task.id)}
                    className="font-medium text-blue-600 dark:text-blue-500 hover:underline mx-1"
                  >
                    Editar
                  </Link>
                  <button
                    onClick={(e) => deleteTask(task)}
                    className="font-medium text-red-600 dark:text-red-500 hover:underline mx-1"
                  >
                    Deletar
                  </button>
                </td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination links={tasks.meta.links} />
    </>
  );
}
