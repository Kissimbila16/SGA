import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import SelectInput from "@/Components/SelectInput";
import TextAreaInput from "@/Components/TextAreaInput";
import TextInput from "@/Components/TextInput";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, Link, useForm } from "@inertiajs/react";

export default function Create({ auth, projects, users }) {
  const { data, setData, post, errors, reset } = useForm({
    image: "",
    name: "",
    status: "",
    num_interno: "",
    conteudo_despacho: "",
    assunto: "",
    description: "",
    due_date: "",
  });

  const onSubmit = (e) => {
  
    e.preventDefault();
    post(route("task.store"));
  };

  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <div className="flex justify-between items-center">
          <h2 className="font-semibold text-xl leading-tight">
            Criar Orientação
          </h2>
        </div>
      }
    >
      <Head title="Tasks" />

      <div className="py-12">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="bg-white  overflow-hidden shadow-sm sm:rounded-lg">
            <form
              onSubmit={onSubmit}
              className="p-4 sm:p-8 bg-white shadow sm:rounded-lg"
            >
              <div>
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_project_id" value="Orientação" />

                <SelectInput
                  name="project_id"
                  id="task_project_id"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("project_id", e.target.value)}
                >
                  <option value="" disabled>Selecione o Actividade</option>
                  {projects.data.map((project) => (
                    <option value={project.id} key={project.id}>
                      {project.name}
                    </option>
                  ))}
                </SelectInput>

                <InputError message={errors.project_id} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_image_path" value="Imagem da Orientação" />
                <TextInput
                  id="task_image_path"
                  type="file"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  name="image"
                  className="mt-1 block w-full"
                  onChange={(e) => setData("image", e.target.files[0])}
                />
                <InputError message={errors.image} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_name" value="Nome da Orientação" />

                <TextInput
                  id="task_name"
                  type="text"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  name="name"
                  value={data.name}
                  className="mt-1 block w-full"
                  isFocused={true}
                  onChange={(e) => setData("name", e.target.value)}
                />

                <InputError message={errors.name} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_name" value="Conteudo do Despacho" />

                <TextInput
                  id="task_name"
                  type="text"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  name="conteudo_despacho"
                  value={data.conteudo_despacho}
                  className="mt-1 block w-full"
                  isFocused={true}
                  onChange={(e) => setData("conteudo_despacho", e.target.value)}
                />

                <InputError message={errors.conteudo_despacho} className="mt-2" />
              </div>


              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_name" value="Nome do assunto" />

                <TextInput
                  id="task_name"
                  type="text"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  name="assunto"
                  value={data.assunto}
                  className="mt-1 block w-full"
                  isFocused={true}
                  onChange={(e) => setData("assunto", e.target.value)}
                />

                <InputError message={errors.assunto} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_name" value="Nº de Ordem" />

                <TextInput
                  id="task_name"
                  type="text"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  name="num_interno"
                  value={data.num_interno}
                  className="mt-1 block w-full"
                  isFocused={true}
                  onChange={(e) => setData("num_interno", e.target.value)}
                />

                <InputError message={errors.num_interno} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_description"
                  value="Descrição"


                />

                <TextAreaInput
                  id="task_description"
                  name="description"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  value={data.description}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("description", e.target.value)}
                />

                <InputError message={errors.description} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_due_date" value="Prazo" />

                <TextInput
                  id="task_due_date"
                  type="date"
                  name="due_date"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  value={data.due_date}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("due_date", e.target.value)}
                />

                <InputError message={errors.due_date} className="mt-2" />
              </div>
              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_status" value="Estado da Orientação" />

                <SelectInput
                  name="status"
                  id="task_status"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("status", e.target.value)}
                >
                  <option value="" disabled>Selecionar estado</option>
                  <option value="pending">Pendente</option>
                  <option value="in_progress">em Progresso</option>
                  <option value="completed">Cumprida</option>
                </SelectInput>

                <InputError message={errors.task_status} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color" htmlFor="task_priority" value="Tipo de Prioridade" />

                <SelectInput
                  name="priority"
                  id="task_priority"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("priority", e.target.value)}
                >
                  <option value="" disabled>Selecone o tipo de Prioridade</option>
                  <option value="low">baixo</option>
                  <option value="medium">medio</option>
                  <option value="high">alto</option>
                </SelectInput>

                <InputError message={errors.priority} className="mt-2" />
              </div>

              <div className="mt-4">
                <InputLabel style={{ color: 'black' }} className="text-gray-900 btn-color " htmlFor="task_assigned_user"
                  value="usuário a ser Atribuido"
                />

                <SelectInput
                  name="assigned_user_id"
                  id="task_assigned_user"
                  style={{ background: 'white', color: 'black', borderColor: '#0d99ff', borderWidth: '2px' }}
                  className="mt-1 block w-full"
                  onChange={(e) => setData("assigned_user_id", e.target.value)}
                >
                  <option value="" disabled > usuário a ser atribuido a tarefa</option>
                  {users.data.map((user) => (
                    <option value={user.id} key={user.id}>
                      {user.name}
                    </option>
                  ))}
                </SelectInput>

                <InputError
                  message={errors.assigned_user_id}
                  className="mt-2"
                />
              </div>

              <div className="mt-4 text-right">
                <Link
                  href={route("task.index")}
                  className="bg-gray-100 py-1 px-3 text-gray-800 rounded shadow transition-all hover:bg-gray-200 mr-2"
                >
                  Cancelar
                </Link>
                <button className="bg-emerald-500 py-1 px-3 text-white  shadow transition-all w-[180px] btn-bg">
                  Submeter
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
