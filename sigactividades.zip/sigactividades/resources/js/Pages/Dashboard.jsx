import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { TASK_STATUS_CLASS_MAP, TASK_STATUS_TEXT_MAP } from "@/constants";
import { Head, Link } from "@inertiajs/react";

export default function Dashboard({
  auth,
  totalPendingTasks,
  myPendingTasks,
  totalProgressTasks,
  myProgressTasks,
  totalCompletedTasks,
  myCompletedTasks,
  activeTasks,
  taskTable,
  Tasks
}) {

  const subrairData = (date1) => {
    var diaActual = new Date();
    diaActual.getDay();
    const diaNormal = diaActual - date1.getDay(); // Difference in milliseconds
    return diaNormal; // Round down to whole days
  }
  return (
    <AuthenticatedLayout
      user={auth.user}
      header={
        <h2 className="text-xl btn-color" style={{fontWeight:'900'}}>
          Painel de Controlo
        </h2>
      }
    >
      <Head title="Dashboard" />

      <div className="py-12">
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 grid grid-cols-3 gap-2">
          <div className="bg-white btn-bg overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 text-white">
              <h3 className="text-white-500 text-2xl font-semibold">
                Actividades pendentes
              </h3>
              <p className="text-xl mt-4">
                <span className="mr-2">{myPendingTasks}</span>/
                <span className="ml-2">{totalPendingTasks}</span>
              </p>
            </div>
          </div>
          <div className="bg-white btn-bg overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 text-white">
              <h3 className="text-white-500 text-2xl font-semibold">
                Actividades em andamento
              </h3>
              <p className="text-xl mt-4">
                <span className="mr-2">{myProgressTasks}</span>/
                <span className="ml-2">{totalProgressTasks}</span>
              </p>
            </div>
          </div>
          <div className="bg-white btn-bg overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 text-white">
              <h3 className="text-white-500 text-2xl font-semibold">
                Actividades concluidas
              </h3>
              <p className="text-xl mt-4">
                <span className="mr-2">{myCompletedTasks}</span>/
                <span className="ml-2">{totalCompletedTasks}</span>
              </p>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
          <div className="bg-white text-gray-500 bg-gray-200 overflow-hidden shadow-sm sm:rounded-lg">
            <div className="p-6 text-white">

              <table className="mt-3 w-full text-sm text-left rtl:text-right  text-white">
                <thead className="text-xs btn-color uppercase bg-white border-b-2 border-gray-500">
                  <tr>
                    <th className="px-3 py-3">Nº</th>
                    <th className="px-3 py-3">Assunto</th>
                    <th className="px-3 py-3">Conteudo do despacho</th>
                    <th className="px-3 py-3">Nome do Projecto</th>
                    <th className="px-3 py-3">Nº de Ordem</th>
                    <th className="px-3 py-3">Data de criação</th>
                    <th className="px-3 py-3">Prazo</th>
                    <th className="px-3 py-3">Observação</th>
                    <th className="px-3 py-3">Alerta</th>
                    <th className="px-3 py-3">Grau de comprimento</th>

                  </tr>
                </thead>

                <tbody>

                  {activeTasks.data.map((task) => (
                    <tr key={task.id} className="bg-pink.100">
                      <td className="px-3 py-2 text-gray-950">{task.id}</td>
                      <td className="px-3 py-2 text-gray-950">
                        {task.assunto}
                      </td>
                      <td className="px-3 py-2 text-gray-950 ">
                        {task.conteudo_despacho}
                      </td>
                      <td className="px-3 py-2 text-gray-950 hover:underline">
                        <Link href={route("project.show", task.project.id)}>
                          {task.project.name}
                        </Link>
                      </td>
                      <td className="px-3 py-2 text-gray-950">
                        {task.num_interno}
                      </td>

                      <td className="px-3 py-2 text-gray-950">
                        {task.created_at}
                      </td>
                      <td className="px-3 py-2 text-gray-950">
                        {task.due_date}
                      </td>
                      <td className="px-3 py-2 text-gray-950">
                        {task.description}
                      </td>
                      <td className={Tasks ? 'bg-pink-900' : 'bg-green-500'}>
                      
                      </td>
                      <td className="px-3 py-2">
                        <button
                          className={
                            " btn px-2 py-1 rounded text-nowrap text-white " +
                            TASK_STATUS_CLASS_MAP[task.status]
                          }
                        >
                          {TASK_STATUS_TEXT_MAP[task.status]}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
