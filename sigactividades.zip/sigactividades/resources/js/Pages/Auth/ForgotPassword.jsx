import GuestLayout from '@/Layouts/GuestLayout';
import InputError from '@/Components/InputError';
import PrimaryButton from '@/Components/PrimaryButton';
import TextInput from '@/Components/TextInput';
import { Head, Link, useForm } from '@inertiajs/react';

export default function ForgotPassword({ status }) {
    const { data, setData, post, processing, errors } = useForm({
        email: '',
    });

    const submit = (e) => {
        e.preventDefault();

        post(route('password.email'));
    };

    return (
        <GuestLayout>
            <Head title="Forgot Password" />
            <Link
                                href={"login"}
                                className="underline text-sm rounded-md letters outline-none "
                            >
                                &lt;Voltar
                            </Link>
            <div className="mb-4 text-sm text-gray-600 dark:text-gray-400">
        
                esqueceu a sua senha? Sem problema. Só deixe-nos o seu Email e nos iremos enviar lhe um email com a link para redifinir a sua senha.
            </div>

            {status && <div className="mb-4 font-medium text-sm text-green-600 dark:text-green-400">{status}</div>}

            <form onSubmit={submit}>
                <TextInput
                    id="email"
                    type="email"
                    name="email"
                    style={{background:'white',borderColor:'#0d99ff',borderWidth:'2px'}}
                    placeHolder="Email"
                    value={data.email}
                    className="mt-1 block w-full"
                    isFocused={true}
                    onChange={(e) => setData('email', e.target.value)}
                />

                <InputError message={errors.email} className="mt-2" />

                <div className="flex items-center justify-end mt-4">
                    <PrimaryButton className="h-[50px] btn w-full" disabled={processing}>
                        Enviar o Link
                    </PrimaryButton>
                </div>
            </form>
        </GuestLayout>
    );
}
