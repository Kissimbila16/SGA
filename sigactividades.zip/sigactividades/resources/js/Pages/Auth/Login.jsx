import { useEffect } from "react";
import Checkbox from "@/Components/Checkbox";
import GuestLayout from "@/Layouts/GuestLayout";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import { Head, Link, useForm } from "@inertiajs/react";

export default function Login({ status, canResetPassword }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        email: "",
        password: "",
        remember: false,
    });

    useEffect(() => {
        return () => {
            reset("password");
        };
    }, []);

    const submit = (e) => {
        e.preventDefault();

        post(route("login"));
    };

    return (
        <GuestLayout>
            <Head title="Log in" />

            {status && (
                <div className="mb-4 font-medium text-sm text-green-600">
                    {status}
                </div>
            )}

            <form onSubmit={submit} className="w-[90%] ml-[5%]">

                <h2 className="text-center mt-[8%] font-bold" style={{ color: '#0d99ff' }}>
                    <div className="img-logotipo mb-0 mt-[-3%]">
                    </div>
                    Sistema de Gestão e Controlo de Orientações
                    <br />
                </h2>

                <div className="flex mt-2">
                    <span class="inline-flex items-center px-3 h-[45px] mt-[0.9%] text-gray-900 bg-gray-100 border  border-gray-50  dark:bg-gray-100 dark:text-gray-400 dark:border-gray-1000">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400 text-2xl " aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 15 13">
                            <path d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914" />
                        </svg>
                    </span>
                    <TextInput
                        id="email"
                        type="email"
                        name="email"
                        style={{ background: 'white', borderWidth: '2px', color: 'black' }}
                        placeHolder="Email"
                        value={data.email}
                        className="mt-1 block w-full text-black h-[45px] mt-[0.8%] line border"
                        autoComplete="username"
                        isFocused={true}
                        onChange={(e) => setData("email", e.target.value)}
                    />

                    <InputError message={errors.email} className="mt-2" />
                </div>

                <div className="mt-4 flex">
                    <span class="inline-flex items-center px-3 h-[45px] mt-[0.9%] text-sm text-gray-900 bg-gray-100 border  border-gray-50 dark:bg-gray-100 dark:text-gray-400 dark:border-gray-100">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 0a10 10 0 1 0 10 10A10.011 10.011 0 0 0 10 0Zm0 5a3 3 0 1 1 0 6 3 3 0 0 1 0-6Zm0 13a8.949 8.949 0 0 1-4.951-1.488A3.987 3.987 0 0 1 9 13h2a3.987 3.987 0 0 1 3.951 3.512A8.949 8.949 0 0 1 10 18Z" />
                        </svg>
                    </span>
                    <TextInput
                        id="password"
                        type="password"
                        name="password"
                        placeHolder="Senha"
                        style={{ background: 'white', borderWidth: '2px', color: 'black' }}
                        value={data.password}
                        className="mt-1 block w-full h-[45px] line mt-[0.9%] border"
                        autoComplete="current-password"
                        onChange={(e) => setData("password", e.target.value)}
                    />

                    <InputError message={errors.password} className="mt-2" />
                </div>

                <PrimaryButton className="mt-7 btn h-[50px] text-center w-full" disabled={processing}>
                    Entrar
                </PrimaryButton>

                <div className="flex items-center">
                    <div className="block mt-4">
                        <label className="flex items-center">
                            <Checkbox
                                style={{ color: '#0d99ff', borderColor: '#fff' }}
                                className="rounded-none border-white"
                                name="remember"
                                checked={data.remember}
                                onChange={(e) =>
                                    setData("remember", e.target.checked)
                                }
                            />
                            <span className="ms-2 text-sm w-[100px] letters flex text-gray-600 dark:text-gray-400" style={{ color: '#0d99ff' }}>
                                lembrar de mim
                            </span>
                        </label>
                    </div>

                    <div className="flex items-center mt-4 justify-end w-full " style={{ color: '#0d99ff' }}>
                        {canResetPassword && (
                            <Link
                                href={route("password.request")}
                                className="underline text-sm rounded-md letters outline-none "
                            >
                                esqueceu a senha?
                            </Link>
                        )}


                    </div>
                </div>
                     <h4 className="text-xl text-center text-gray-500 mt-5 ml-[-5%]" style={{fontSize:'10px'}}>
                        desenvolvido pela JFtech
                     </h4>
            </form>

        </GuestLayout>
    );
}
