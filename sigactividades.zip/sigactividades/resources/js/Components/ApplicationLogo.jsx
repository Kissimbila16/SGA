export default function ApplicationLogo(props) {
    return (
        <h4 className="text-white font-bold text-2xl mt-2">
       Sistema de Gestão de Controlo de Orientações
       </h4>);
}
