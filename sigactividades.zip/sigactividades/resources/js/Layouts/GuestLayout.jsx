import ApplicationLogo from '@/Components/ApplicationLogo';
import { Link } from '@inertiajs/react';

export default function Guest({ children }) {
    return (
        <div className="min-h-screen flex flex-col sm:justify-center items-center  gradient-blue">
            <section className="w-[50%]" style={{ display: 'flex' }}>
                <div className="w-[50%] h-[410px] mt-4 btn-bg div-left">
                   
                    <div className="flex w-25 text-center mt-[35%] h-[100px]">
<h5 className='ml-8 w-25'>
     
</h5>
                        <span className='text-left ml-[-5%]'>
                            <h4 className='txt-center ml-4 text-2xl  text-white font-bold' style={{ fontFamily: 'arial' }}>
                                SGCO-PUREZA <br />
                            </h4>
                            <h4 className='mt-[-2%] ml-4 text-gray-100 font-bold  text-1xl'>
                              INSPECÇÃO DA POLICÍA NACIONAL
                            </h4>
                        </span>
                    </div></div>

                <div className="log w-[50%] h-[410px] mt-4 px-6 py-4 bg-white shadow-md overflow-hidden div-right">
                    {children}
                </div>
            </section>
        </div>
    );
}
